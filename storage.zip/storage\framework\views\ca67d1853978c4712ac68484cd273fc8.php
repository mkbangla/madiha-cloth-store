
<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 py-10">

    
    <nav class="text-sm text-gray-400 mb-8">
        <a href="<?php echo e(route('home')); ?>" class="hover:text-gray-700">Home</a> /
        <a href="<?php echo e(route('shop')); ?>" class="hover:text-gray-700">Shop</a> /
        <a href="<?php echo e(route('shop.category', $product->category)); ?>" class="hover:text-gray-700"><?php echo e($product->category->name); ?></a> /
        <span class="text-gray-700"><?php echo e($product->name); ?></span>
    </nav>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">

        
        <div>
            
            <div class="bg-gray-100 rounded-2xl overflow-hidden aspect-square mb-3" id="main-image-wrap">
                <img id="main-image"
                     src="<?php echo e($product->image_url); ?>"
                     alt="<?php echo e($product->name); ?>"
                     class="w-full h-full object-cover">
            </div>

            
            <?php if($product->images->count() > 1): ?>
                <div class="grid grid-cols-5 gap-2">
                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button onclick="document.getElementById('main-image').src='<?php echo e($image->url); ?>'"
                                class="bg-gray-100 rounded-lg overflow-hidden aspect-square hover:ring-2 ring-gray-900 transition-all">
                            <img src="<?php echo e($image->url); ?>" alt="" class="w-full h-full object-cover">
                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

        
        <div>
            <p class="text-sm text-gray-400 mb-2"><?php echo e($product->category->name); ?></p>
            <h1 class="text-3xl font-bold text-gray-900 mb-3"><?php echo e($product->name); ?></h1>

            
            <div class="flex items-baseline gap-3 mb-6">
                <span class="text-2xl font-bold text-gray-900">৳<?php echo e(number_format($product->current_price)); ?></span>
                <?php if($product->is_on_sale): ?>
                    <span class="text-lg text-gray-400 line-through">৳<?php echo e(number_format($product->price)); ?></span>
                    <span class="bg-red-100 text-red-600 text-sm font-medium px-2 py-0.5 rounded">
                        <?php echo e(round((1 - $product->sale_price / $product->price) * 100)); ?>% OFF
                    </span>
                <?php endif; ?>
            </div>

            
            <?php if($product->is_out_of_stock): ?>
                <p class="text-red-500 text-sm font-medium mb-4"><i class="fas fa-times-circle mr-1"></i>Out of Stock</p>
            <?php elseif($product->is_low_stock): ?>
                <p class="text-orange-500 text-sm font-medium mb-4"><i class="fas fa-exclamation-circle mr-1"></i>Only <?php echo e($product->stock); ?> left!</p>
            <?php else: ?>
                <p class="text-green-600 text-sm font-medium mb-4"><i class="fas fa-check-circle mr-1"></i>In Stock</p>
            <?php endif; ?>

            <p class="text-gray-600 leading-relaxed mb-8"><?php echo e($product->short_description); ?></p>

            
            <?php if(!$product->is_out_of_stock): ?>
                <form action="<?php echo e(route('cart.add', $product)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    
                    <?php if(!empty($product->sizes)): ?>
                        <div class="mb-5">
                            <p class="text-sm font-medium text-gray-700 mb-2">Size</p>
                            <div class="flex gap-2 flex-wrap">
                                <?php $__currentLoopData = $product->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="cursor-pointer">
                                        <input type="radio" name="size" value="<?php echo e($size); ?>" class="sr-only size-radio" required>
                                        <span class="size-btn inline-block border border-gray-300 text-sm px-3 py-1.5 rounded-lg hover:border-gray-900 transition-colors cursor-pointer">
                                            <?php echo e($size); ?>

                                        </span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(!empty($product->colors)): ?>
                        <div class="mb-5">
                            <p class="text-sm font-medium text-gray-700 mb-2">Color</p>
                            <div class="flex gap-2 flex-wrap">
                                <?php $__currentLoopData = $product->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="cursor-pointer">
                                        <input type="radio" name="color" value="<?php echo e($color); ?>" class="sr-only color-radio">
                                        <span class="color-btn inline-block border border-gray-300 text-sm px-3 py-1.5 rounded-lg hover:border-gray-900 transition-colors cursor-pointer">
                                            <?php echo e($color); ?>

                                        </span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    
                    <div class="mb-6">
                        <p class="text-sm font-medium text-gray-700 mb-2">Quantity</p>
                        <div class="flex items-center gap-3">
                            <button type="button" onclick="adjustQty(-1)"
                                    class="w-10 h-10 border border-gray-300 rounded-lg flex items-center justify-center hover:bg-gray-50">−</button>
                            <input type="number" id="qty-input" name="quantity" value="1" min="1" max="<?php echo e($product->stock); ?>"
                                   class="w-16 text-center border border-gray-300 rounded-lg py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gray-900">
                            <button type="button" onclick="adjustQty(1)"
                                    class="w-10 h-10 border border-gray-300 rounded-lg flex items-center justify-center hover:bg-gray-50">+</button>
                        </div>
                    </div>

                    <button type="submit" class="w-full btn-primary py-4 text-base rounded-xl">
                        <i class="fas fa-shopping-bag mr-2"></i>Add to Cart
                    </button>
                </form>
            <?php else: ?>
                <button disabled class="w-full bg-gray-200 text-gray-400 py-4 rounded-xl text-base cursor-not-allowed">
                    Out of Stock
                </button>
            <?php endif; ?>

            
            <?php if($product->sku): ?>
                <p class="text-xs text-gray-400 mt-4">SKU: <?php echo e($product->sku); ?></p>
            <?php endif; ?>

            
            <div class="mt-8 border-t border-gray-100 pt-8">
                <h3 class="font-semibold text-gray-900 mb-3">Product Description</h3>
                <p class="text-gray-600 text-sm leading-relaxed"><?php echo e($product->description); ?></p>
            </div>
        </div>
    </div>

    
    <?php if($related->count()): ?>
        <section>
            <h2 class="text-xl font-bold text-gray-900 mb-6">You May Also Like</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
                <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.product-card', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function adjustQty(delta) {
    const input = document.getElementById('qty-input');
    const val   = parseInt(input.value) + delta;
    const max   = parseInt(input.max);
    if (val >= 1 && val <= max) input.value = val;
}

// Size selection
document.querySelectorAll('.size-radio').forEach(radio => {
    radio.addEventListener('change', function() {
        document.querySelectorAll('.size-btn').forEach(btn => {
            btn.style.backgroundColor = '';
            btn.style.color = '';
            btn.style.borderColor = '#D1D5DB';
        });
        this.nextElementSibling.style.backgroundColor = '#111827';
        this.nextElementSibling.style.color = '#ffffff';
        this.nextElementSibling.style.borderColor = '#111827';
    });
});

// Color selection
document.querySelectorAll('.color-radio').forEach(radio => {
    radio.addEventListener('change', function() {
        document.querySelectorAll('.color-btn').forEach(btn => {
            btn.style.backgroundColor = '';
            btn.style.color = '';
            btn.style.borderColor = '#D1D5DB';
        });
        this.nextElementSibling.style.backgroundColor = '#111827';
        this.nextElementSibling.style.color = '#ffffff';
        this.nextElementSibling.style.borderColor = '#111827';
    });
});

// Quantity
function adjustQty(delta) {
    const input = document.getElementById('qty-input');
    const val   = parseInt(input.value) + delta;
    const max   = parseInt(input.max);
    if (val >= 1 && val <= max) input.value = val;
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Laravel_Tutorial\claude\madiha-cloth-store\resources\views/shop/show.blade.php ENDPATH**/ ?>