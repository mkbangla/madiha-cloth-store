
<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('page-title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between mb-6">
    <form action="<?php echo e(route('admin.products.index')); ?>" method="GET" class="flex gap-2">
        <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Search products..."
               class="border border-gray-200 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gray-300 w-64">
        <select name="category_id" class="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none">
            <option value="">All Categories</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category_id') == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg text-sm hover:bg-gray-200">Filter</button>
    </form>
    <a href="<?php echo e(route('admin.products.create')); ?>"
       class="bg-gray-900 text-white px-4 py-2 rounded-lg text-sm hover:bg-gray-700 transition-colors flex items-center gap-2">
        <i class="fas fa-plus"></i> Add Product
    </a>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
            <tr>
                <th class="px-5 py-3 text-left">Product</th>
                <th class="px-5 py-3 text-left">Category</th>
                <th class="px-5 py-3 text-left">Price</th>
                <th class="px-5 py-3 text-left">Stock</th>
                <th class="px-5 py-3 text-left">Status</th>
                <th class="px-5 py-3 text-left">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 transition-colors">
                    <td class="px-5 py-3">
                        <div class="flex items-center gap-3">
                            <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>"
                                 class="w-10 h-10 rounded-lg object-cover bg-gray-100">
                            <div>
                                <p class="font-medium text-gray-900"><?php echo e($product->name); ?></p>
                                <p class="text-xs text-gray-400">SKU: <?php echo e($product->sku ?? 'N/A'); ?></p>
                            </div>
                        </div>
                    </td>
                    <td class="px-5 py-3 text-gray-600"><?php echo e($product->category->name); ?></td>
                    <td class="px-5 py-3">
                        <span class="font-medium">৳<?php echo e(number_format($product->current_price)); ?></span>
                        <?php if($product->is_on_sale): ?>
                            <span class="text-xs text-gray-400 line-through ml-1">৳<?php echo e(number_format($product->price)); ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="px-5 py-3">
                        <span class="font-medium <?php echo e($product->stock == 0 ? 'text-red-500' : ($product->is_low_stock ? 'text-orange-500' : 'text-gray-700')); ?>">
                            <?php echo e($product->stock); ?>

                        </span>
                    </td>
                    <td class="px-5 py-3">
                        <span class="px-2 py-1 rounded-full text-xs font-medium <?php echo e($product->is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'); ?>">
                            <?php echo e($product->is_active ? 'Active' : 'Inactive'); ?>

                        </span>
                        <?php if($product->is_featured): ?>
                            <span class="px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700 ml-1">Featured</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-5 py-3">
                        <div class="flex items-center gap-2">
                            <a href="<?php echo e(route('admin.products.edit', $product)); ?>"
                               class="text-blue-500 hover:text-blue-700 text-xs font-medium">Edit</a>
                            <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="POST"
                                  onsubmit="return confirm('Delete this product?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="text-red-400 hover:text-red-600 text-xs font-medium">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-5 py-12 text-center text-gray-400">
                        No products found.
                        <a href="<?php echo e(route('admin.products.create')); ?>" class="text-gray-700 underline ml-1">Add one</a>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <div class="px-5 py-4 border-t border-gray-100">
        <?php echo e($products->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Laravel_Tutorial\claude\madiha-cloth-store\resources\views/admin/products/index.blade.php ENDPATH**/ ?>