
<?php $__env->startSection('title', 'Customers'); ?>
<?php $__env->startSection('page-title', 'Customers'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
            <tr>
                <th class="px-5 py-3 text-left">Customer</th>
                <th class="px-5 py-3 text-left">Email</th>
                <th class="px-5 py-3 text-left">Orders</th>
                <th class="px-5 py-3 text-left">Joined</th>
                <th class="px-5 py-3 text-left">Action</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
            <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-5 py-3">
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-xs font-bold text-gray-600">
                                <?php echo e(strtoupper(substr($customer->name, 0, 1))); ?>

                            </div>
                            <span class="font-medium text-gray-800"><?php echo e($customer->name); ?></span>
                        </div>
                    </td>
                    <td class="px-5 py-3 text-gray-600"><?php echo e($customer->email); ?></td>
                    <td class="px-5 py-3 text-gray-600"><?php echo e($customer->orders_count); ?></td>
                    <td class="px-5 py-3 text-gray-400 text-xs"><?php echo e($customer->created_at->format('M d, Y')); ?></td>
                    <td class="px-5 py-3">
                        <a href="<?php echo e(route('admin.customers.show', $customer)); ?>"
                           class="text-blue-500 hover:text-blue-700 text-xs font-medium">View</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="px-5 py-12 text-center text-gray-400">No customers yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    <div class="px-5 py-4 border-t border-gray-100"><?php echo e($customers->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Laravel_Tutorial\claude\madiha-cloth-store\resources\views/admin/customers/index.blade.php ENDPATH**/ ?>