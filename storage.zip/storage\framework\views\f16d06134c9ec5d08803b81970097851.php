
<?php $__env->startSection('title', 'Cart'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto px-4 sm:px-6 py-10">
    <h1 class="text-2xl font-bold text-gray-900 mb-8">Shopping Cart</h1>

    <?php if(empty($items)): ?>
        <div class="text-center py-24">
            <i class="fas fa-shopping-bag text-5xl text-gray-200 mb-6"></i>
            <h2 class="text-xl font-semibold text-gray-700 mb-2">Your cart is empty</h2>
            <p class="text-gray-400 mb-8">Add some products and come back here.</p>
            <a href="<?php echo e(route('shop')); ?>" class="btn-primary">Continue Shopping</a>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">

            
            <div class="lg:col-span-2 space-y-4">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowId => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex gap-4 bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
                        <img src="<?php echo e($item['image']); ?>" alt="<?php echo e($item['name']); ?>"
                             class="w-24 h-24 object-cover rounded-lg bg-gray-100 flex-shrink-0">

                        <div class="flex-1">
                            <div class="flex justify-between items-start">
                                <div>
                                    <a href="<?php echo e(route('product.show', $item['slug'])); ?>"
                                       class="font-medium text-gray-900 hover:text-gray-600">
                                        <?php echo e($item['name']); ?>

                                    </a>
                                    <p class="text-sm text-gray-400 mt-0.5">
                                        <?php if($item['size']): ?>  Size: <?php echo e($item['size']); ?> <?php endif; ?>
                                        <?php if($item['color']): ?> &nbsp;· Color: <?php echo e($item['color']); ?> <?php endif; ?>
                                    </p>
                                </div>
                                <form action="<?php echo e(route('cart.remove', $rowId)); ?>" method="POST">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="text-gray-300 hover:text-red-400 transition-colors ml-4">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </form>
                            </div>

                            <div class="flex items-center justify-between mt-3">
                                <div class="flex items-center gap-2">
                                    <form action="<?php echo e(route('cart.update', $rowId)); ?>" method="POST">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <div class="flex items-center gap-2">
                                            <button type="submit" name="quantity" value="<?php echo e($item['quantity'] - 1); ?>"
                                                    class="w-7 h-7 border border-gray-200 rounded text-sm hover:bg-gray-50 flex items-center justify-center">−</button>
                                            <span class="w-8 text-center text-sm font-medium"><?php echo e($item['quantity']); ?></span>
                                            <button type="submit" name="quantity" value="<?php echo e($item['quantity'] + 1); ?>"
                                                    class="w-7 h-7 border border-gray-200 rounded text-sm hover:bg-gray-50 flex items-center justify-center">+</button>
                                        </div>
                                    </form>
                                </div>
                                <span class="font-semibold text-gray-900">
                                    ৳<?php echo e(number_format($item['price'] * $item['quantity'])); ?>

                                </span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <div class="bg-gray-50 rounded-2xl p-6 h-fit">
                <h2 class="font-semibold text-gray-900 mb-6">Order Summary</h2>

                
                <?php if($coupon): ?>
                    <div class="flex items-center justify-between bg-green-50 border border-green-200 rounded-lg px-3 py-2 mb-4">
                        <div>
                            <span class="text-green-700 text-sm font-medium"><?php echo e($coupon['code']); ?></span>
                            <p class="text-green-600 text-xs">−৳<?php echo e(number_format($coupon['discount'])); ?> saved</p>
                        </div>
                        <form action="<?php echo e(route('coupon.remove')); ?>" method="POST">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="text-green-500 text-xs hover:text-green-700">Remove</button>
                        </form>
                    </div>
                <?php else: ?>
                    <form action="<?php echo e(route('coupon.apply')); ?>" method="POST" class="flex gap-2 mb-4">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="coupon_code" placeholder="Coupon code"
                               class="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gray-300">
                        <button class="bg-gray-900 text-white px-4 py-2 rounded-lg text-sm hover:bg-gray-700 transition-colors">
                            Apply
                        </button>
                    </form>
                    <?php if(session('coupon_error')): ?>
                        <p class="text-red-500 text-xs mb-3"><?php echo e(session('coupon_error')); ?></p>
                    <?php endif; ?>
                <?php endif; ?>

                
                <div class="space-y-3 border-t border-gray-200 pt-4 mb-4">
                    <div class="flex justify-between text-sm text-gray-600">
                        <span>Subtotal</span>
                        <span>৳<?php echo e(number_format($subtotal)); ?></span>
                    </div>
                    <?php if($discount > 0): ?>
                        <div class="flex justify-between text-sm text-green-600">
                            <span>Discount</span>
                            <span>−৳<?php echo e(number_format($discount)); ?></span>
                        </div>
                    <?php endif; ?>
                    <div class="flex justify-between font-bold text-gray-900 text-base border-t border-gray-200 pt-3">
                        <span>Total</span>
                        <span>৳<?php echo e(number_format($total)); ?></span>
                    </div>
                </div>

                <a href="<?php echo e(route('checkout.index')); ?>"
                   class="block text-center bg-gray-900 text-white py-4 rounded-xl text-sm font-medium hover:bg-gray-700 transition-colors">
                    Proceed to Checkout
                </a>
                <a href="<?php echo e(route('shop')); ?>"
                   class="block text-center text-sm text-gray-400 hover:text-gray-700 mt-3">
                    ← Continue Shopping
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Laravel_Tutorial\claude\madiha-cloth-store\resources\views/cart/index.blade.php ENDPATH**/ ?>