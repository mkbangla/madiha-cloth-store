
<?php $__env->startSection('title', isset($category) ? $category->name : 'Shop'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 py-10">

    
    <nav class="text-sm text-gray-400 mb-6">
        <a href="<?php echo e(route('home')); ?>" class="hover:text-gray-700">Home</a>
        <span class="mx-2">/</span>
        <span class="text-gray-700"><?php echo e(isset($category) ? $category->name : 'Shop'); ?></span>
    </nav>

    <div class="flex gap-8">

        
        <aside class="hidden md:block w-56 flex-shrink-0">
            <h3 class="font-semibold text-gray-900 mb-4">Categories</h3>
            <ul class="space-y-2 mb-8">
                <li>
                    <a href="<?php echo e(route('shop')); ?>"
                       class="text-sm <?php echo e(!isset($category) ? 'font-semibold text-gray-900' : 'text-gray-500 hover:text-gray-900'); ?>">
                        All Products
                    </a>
                </li>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('shop.category', $cat)); ?>"
                           class="text-sm <?php echo e(isset($category) && $category->id === $cat->id ? 'font-semibold text-gray-900' : 'text-gray-500 hover:text-gray-900'); ?>">
                            <?php echo e($cat->name); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <h3 class="font-semibold text-gray-900 mb-4">Price Range</h3>
            <form action="<?php echo e(route('shop')); ?>" method="GET">
                <?php if(isset($category)): ?>
                    <input type="hidden" name="category" value="<?php echo e($category->id); ?>">
                <?php endif; ?>
                <div class="flex gap-2 mb-3">
                    <input type="number" name="min_price" placeholder="Min ৳" value="<?php echo e(request('min_price')); ?>"
                           class="w-full border border-gray-200 rounded px-2 py-1.5 text-sm">
                    <input type="number" name="max_price" placeholder="Max ৳" value="<?php echo e(request('max_price')); ?>"
                           class="w-full border border-gray-200 rounded px-2 py-1.5 text-sm">
                </div>
                <button class="w-full bg-gray-900 text-white text-sm py-2 rounded hover:bg-gray-700 transition-colors">
                    Apply
                </button>
            </form>
        </aside>

        
        <div class="flex-1">

            
            <div class="flex items-center justify-between mb-6">
                <p class="text-sm text-gray-500"><?php echo e($products->total()); ?> products</p>
                <form action="<?php echo e(route('shop')); ?>" method="GET">
                    <select name="sort" onchange="this.form.submit()"
                            class="border border-gray-200 rounded px-3 py-2 text-sm text-gray-700 focus:outline-none">
                        <option value="latest"    <?php echo e(request('sort') === 'latest'     ? 'selected' : ''); ?>>Latest</option>
                        <option value="price_asc" <?php echo e(request('sort') === 'price_asc'  ? 'selected' : ''); ?>>Price: Low → High</option>
                        <option value="price_desc"<?php echo e(request('sort') === 'price_desc' ? 'selected' : ''); ?>>Price: High → Low</option>
                        <option value="name"      <?php echo e(request('sort') === 'name'       ? 'selected' : ''); ?>>Name A–Z</option>
                    </select>
                </form>
            </div>

            
            <?php if($products->count()): ?>
                <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-5">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('partials.product-card', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="mt-10"><?php echo e($products->links()); ?></div>
            <?php else: ?>
                <div class="text-center py-20 text-gray-400">
                    <i class="fas fa-box-open text-4xl mb-4"></i>
                    <p>No products found.</p>
                    <a href="<?php echo e(route('shop')); ?>" class="text-gray-700 underline text-sm mt-2 block">Clear filters</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Laravel_Tutorial\claude\madiha-cloth-store\resources\views/shop/index.blade.php ENDPATH**/ ?>