
<?php $__env->startSection('title', 'Orders'); ?>
<?php $__env->startSection('page-title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <form action="<?php echo e(route('admin.orders.index')); ?>" method="GET" class="flex gap-2">
        <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Search order number or customer..."
               class="border border-gray-200 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gray-300 w-72">
        <select name="status" class="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none">
            <option value="">All Status</option>
            <?php $__currentLoopData = ['pending','processing','shipped','delivered','cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($s); ?>" <?php echo e(request('status') === $s ? 'selected' : ''); ?>><?php echo e(ucfirst($s)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg text-sm hover:bg-gray-200">Filter</button>
    </form>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
            <tr>
                <th class="px-5 py-3 text-left">Order</th>
                <th class="px-5 py-3 text-left">Customer</th>
                <th class="px-5 py-3 text-left">Items</th>
                <th class="px-5 py-3 text-left">Total</th>
                <th class="px-5 py-3 text-left">Status</th>
                <th class="px-5 py-3 text-left">Date</th>
                <th class="px-5 py-3 text-left">Action</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-5 py-3 font-medium text-gray-900"><?php echo e($order->order_number); ?></td>
                    <td class="px-5 py-3">
                        <p class="text-gray-800 font-medium"><?php echo e($order->shipping_name); ?></p>
                        <p class="text-xs text-gray-400"><?php echo e($order->shipping_email); ?></p>
                    </td>
                    <td class="px-5 py-3 text-gray-600"><?php echo e($order->items->count()); ?> items</td>
                    <td class="px-5 py-3 font-semibold">৳<?php echo e(number_format($order->total)); ?></td>
                    <td class="px-5 py-3">
                        <span class="px-2 py-1 rounded-full text-xs font-medium capitalize
                            <?php echo e(match($order->status) {
                                'pending'    => 'bg-yellow-100 text-yellow-700',
                                'processing' => 'bg-blue-100 text-blue-700',
                                'shipped'    => 'bg-purple-100 text-purple-700',
                                'delivered'  => 'bg-green-100 text-green-700',
                                'cancelled'  => 'bg-red-100 text-red-700',
                                default      => 'bg-gray-100 text-gray-700',
                            }); ?>">
                            <?php echo e($order->status); ?>

                        </span>
                    </td>
                    <td class="px-5 py-3 text-gray-400 text-xs"><?php echo e($order->created_at->format('M d, Y')); ?></td>
                    <td class="px-5 py-3">
                        <a href="<?php echo e(route('admin.orders.show', $order)); ?>"
                           class="text-blue-500 hover:text-blue-700 text-xs font-medium">View</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="px-5 py-12 text-center text-gray-400">No orders found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    <div class="px-5 py-4 border-t border-gray-100"><?php echo e($orders->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Laravel_Tutorial\claude\madiha-cloth-store\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>