<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>


<div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5 mb-8">
    <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
        <div class="flex items-center justify-between mb-3">
            <p class="text-sm text-gray-500">Total Revenue</p>
            <div class="w-9 h-9 bg-green-100 rounded-lg flex items-center justify-center">
                <i class="fas fa-dollar-sign text-green-600 text-sm"></i>
            </div>
        </div>
        <p class="text-2xl font-bold text-gray-900">৳<?php echo e(number_format($totalRevenue)); ?></p>
        <p class="text-xs text-green-600 mt-1">৳<?php echo e(number_format($monthRevenue)); ?> this month</p>
    </div>

    <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
        <div class="flex items-center justify-between mb-3">
            <p class="text-sm text-gray-500">Total Orders</p>
            <div class="w-9 h-9 bg-blue-100 rounded-lg flex items-center justify-center">
                <i class="fas fa-bag-shopping text-blue-600 text-sm"></i>
            </div>
        </div>
        <p class="text-2xl font-bold text-gray-900"><?php echo e(number_format($totalOrders)); ?></p>
        <p class="text-xs text-blue-600 mt-1"><?php echo e($monthOrders); ?> this month</p>
    </div>

    <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
        <div class="flex items-center justify-between mb-3">
            <p class="text-sm text-gray-500">Total Products</p>
            <div class="w-9 h-9 bg-purple-100 rounded-lg flex items-center justify-center">
                <i class="fas fa-shirt text-purple-600 text-sm"></i>
            </div>
        </div>
        <p class="text-2xl font-bold text-gray-900"><?php echo e($totalProducts); ?></p>
        <p class="text-xs text-red-500 mt-1"><?php echo e($outOfStockCount); ?> out of stock</p>
    </div>

    <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
        <div class="flex items-center justify-between mb-3">
            <p class="text-sm text-gray-500">Customers</p>
            <div class="w-9 h-9 bg-orange-100 rounded-lg flex items-center justify-center">
                <i class="fas fa-users text-orange-600 text-sm"></i>
            </div>
        </div>
        <p class="text-2xl font-bold text-gray-900"><?php echo e(number_format($totalCustomers)); ?></p>
        <p class="text-xs text-gray-400 mt-1">Registered users</p>
    </div>
</div>


<div class="grid grid-cols-1 xl:grid-cols-3 gap-5 mb-8">
    <div class="xl:col-span-2 bg-white rounded-xl p-5 shadow-sm border border-gray-100">
        <h3 class="font-semibold text-gray-800 mb-4">Revenue — Last 7 Days</h3>
        <canvas id="revenueChart" height="100"></canvas>
    </div>

    <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
        <h3 class="font-semibold text-gray-800 mb-4">Orders by Status</h3>
        <div class="space-y-3">
            <?php
                $statusColors = [
                    'pending'    => 'bg-yellow-400',
                    'processing' => 'bg-blue-400',
                    'shipped'    => 'bg-purple-400',
                    'delivered'  => 'bg-green-400',
                    'cancelled'  => 'bg-red-400',
                ];
            ?>
            <?php $__currentLoopData = $ordersByStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-2">
                        <div class="w-2.5 h-2.5 rounded-full <?php echo e($statusColors[$status] ?? 'bg-gray-400'); ?>"></div>
                        <span class="text-sm text-gray-600 capitalize"><?php echo e($status); ?></span>
                    </div>
                    <span class="text-sm font-semibold text-gray-900"><?php echo e($count); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($ordersByStatus->isEmpty()): ?>
                <p class="text-sm text-gray-400 text-center py-4">No orders yet</p>
            <?php endif; ?>
        </div>
    </div>
</div>


<div class="grid grid-cols-1 xl:grid-cols-3 gap-5 mb-8">
    <div class="xl:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <h3 class="font-semibold text-gray-800">Recent Orders</h3>
            <a href="<?php echo e(route('admin.orders.index')); ?>" class="text-xs text-gray-400 hover:text-gray-700">View all →</a>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
                    <tr>
                        <th class="px-5 py-3 text-left">Order</th>
                        <th class="px-5 py-3 text-left">Customer</th>
                        <th class="px-5 py-3 text-left">Total</th>
                        <th class="px-5 py-3 text-left">Status</th>
                        <th class="px-5 py-3 text-left">Date</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-5 py-3">
                                <a href="<?php echo e(route('admin.orders.show', $order)); ?>"
                                   class="font-medium text-gray-900 hover:text-blue-600">
                                    <?php echo e($order->order_number); ?>

                                </a>
                            </td>
                            <td class="px-5 py-3 text-gray-600"><?php echo e($order->shipping_name); ?></td>
                            <td class="px-5 py-3 font-medium">৳<?php echo e(number_format($order->total)); ?></td>
                            <td class="px-5 py-3">
                                <span class="px-2 py-1 rounded-full text-xs font-medium capitalize
                                    <?php echo e(match($order->status) {
                                        'pending'    => 'bg-yellow-100 text-yellow-700',
                                        'processing' => 'bg-blue-100 text-blue-700',
                                        'shipped'    => 'bg-purple-100 text-purple-700',
                                        'delivered'  => 'bg-green-100 text-green-700',
                                        'cancelled'  => 'bg-red-100 text-red-700',
                                        default      => 'bg-gray-100 text-gray-700',
                                    }); ?>">
                                    <?php echo e($order->status); ?>

                                </span>
                            </td>
                            <td class="px-5 py-3 text-gray-400 text-xs">
                                <?php echo e($order->created_at->format('M d, Y')); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-5 py-8 text-center text-gray-400">No orders yet</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <h3 class="font-semibold text-gray-800">Low Stock Alert</h3>
            <a href="<?php echo e(route('admin.inventory.index')); ?>" class="text-xs text-gray-400 hover:text-gray-700">View all →</a>
        </div>
        <div class="divide-y divide-gray-50">
            <?php $__empty_1 = true; $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="px-5 py-3 flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-800"><?php echo e(Str::limit($product->name, 25)); ?></p>
                        <p class="text-xs text-gray-400"><?php echo e($product->category->name ?? ''); ?></p>
                    </div>
                    <span class="text-sm font-bold <?php echo e($product->stock <= 2 ? 'text-red-500' : 'text-orange-500'); ?>">
                        <?php echo e($product->stock); ?> left
                    </span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="px-5 py-8 text-center text-gray-400 text-sm">
                    <i class="fas fa-check-circle text-green-400 text-2xl mb-2 block"></i>
                    All products well stocked!
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="px-5 py-4 border-b border-gray-100">
        <h3 class="font-semibold text-gray-800">Top Products by Revenue</h3>
    </div>
    <table class="w-full text-sm">
        <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
            <tr>
                <th class="px-5 py-3 text-left">#</th>
                <th class="px-5 py-3 text-left">Product</th>
                <th class="px-5 py-3 text-left">Units Sold</th>
                <th class="px-5 py-3 text-left">Revenue</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
            <?php $__empty_1 = true; $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-5 py-3 text-gray-400 font-medium"><?php echo e($i + 1); ?></td>
                    <td class="px-5 py-3 font-medium text-gray-800"><?php echo e($product->name); ?></td>
                    <td class="px-5 py-3 text-gray-600"><?php echo e($product->units); ?></td>
                    <td class="px-5 py-3 font-semibold text-gray-900">৳<?php echo e(number_format($product->revenue)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="px-5 py-8 text-center text-gray-400">No sales data yet</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
const ctx = document.getElementById('revenueChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($chartDays); ?>,
        datasets: [{
            label: 'Revenue (৳)',
            data: <?php echo json_encode($chartRevenues); ?>,
            borderColor: '#111827',
            backgroundColor: 'rgba(17,24,39,0.06)',
            borderWidth: 2,
            pointBackgroundColor: '#111827',
            pointRadius: 4,
            tension: 0.4,
            fill: true,
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
            y: {
                beginAtZero: true,
                grid: { color: 'rgba(0,0,0,0.04)' },
                ticks: { callback: v => '৳' + v.toLocaleString() }
            },
            x: { grid: { display: false } }
        }
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Laravel_Tutorial\claude\madiha-cloth-store\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>