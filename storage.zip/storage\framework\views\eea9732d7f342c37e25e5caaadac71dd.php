<div class="group">
    <a href="<?php echo e(route('product.show', $product)); ?>" class="block">
        <div class="relative bg-gray-100 rounded-xl overflow-hidden aspect-[3/4] mb-3">
            <img src="<?php echo e($product->image_url); ?>"
                 alt="<?php echo e($product->name); ?>"
                 class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">

            
            <div class="absolute top-2 left-2 flex flex-col gap-1">
                <?php if($product->is_on_sale): ?>
                    <span class="bg-red-500 text-white text-xs px-2 py-0.5 rounded font-medium">Sale</span>
                <?php endif; ?>
                <?php if($product->is_out_of_stock): ?>
                    <span class="bg-gray-600 text-white text-xs px-2 py-0.5 rounded font-medium">Sold Out</span>
                <?php elseif($product->is_low_stock): ?>
                    <span class="bg-orange-400 text-white text-xs px-2 py-0.5 rounded font-medium">Low Stock</span>
                <?php endif; ?>
            </div>

            
            <?php if(!$product->is_out_of_stock): ?>
                <div class="absolute bottom-0 left-0 right-0 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    <form action="<?php echo e(route('cart.add', $product)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="w-full bg-gray-900 text-white text-sm py-3 font-medium hover:bg-gray-700 transition-colors">
                            Quick Add
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </a>

    <div>
        <p class="text-xs text-gray-400 mb-1"><?php echo e($product->category->name ?? ''); ?></p>
        <a href="<?php echo e(route('product.show', $product)); ?>" class="text-sm font-medium text-gray-900 hover:text-gray-600 block leading-snug mb-1">
            <?php echo e($product->name); ?>

        </a>
        <div class="flex items-center gap-2">
            <span class="text-sm font-semibold text-gray-900">৳<?php echo e(number_format($product->current_price)); ?></span>
            <?php if($product->is_on_sale): ?>
                <span class="text-xs text-gray-400 line-through">৳<?php echo e(number_format($product->price)); ?></span>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH G:\Laravel_Tutorial\claude\madiha-cloth-store\resources\views/partials/product-card.blade.php ENDPATH**/ ?>