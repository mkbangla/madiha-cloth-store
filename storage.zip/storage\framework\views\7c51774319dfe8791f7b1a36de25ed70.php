
<?php $__env->startSection('title', 'Coupons'); ?>
<?php $__env->startSection('page-title', 'Coupons'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-end mb-6">
    <a href="<?php echo e(route('admin.coupons.create')); ?>"
       class="bg-gray-900 text-white px-4 py-2 rounded-lg text-sm hover:bg-gray-700 transition-colors flex items-center gap-2">
        <i class="fas fa-plus"></i> Add Coupon
    </a>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
            <tr>
                <th class="px-5 py-3 text-left">Code</th>
                <th class="px-5 py-3 text-left">Type</th>
                <th class="px-5 py-3 text-left">Value</th>
                <th class="px-5 py-3 text-left">Min Order</th>
                <th class="px-5 py-3 text-left">Used</th>
                <th class="px-5 py-3 text-left">Expires</th>
                <th class="px-5 py-3 text-left">Status</th>
                <th class="px-5 py-3 text-left">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
            <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-5 py-3">
                        <span class="font-mono font-bold text-gray-900"><?php echo e($coupon->code); ?></span>
                    </td>
                    <td class="px-5 py-3 capitalize text-gray-600"><?php echo e($coupon->type); ?></td>
                    <td class="px-5 py-3 font-medium">
                        <?php echo e($coupon->type === 'percentage' ? $coupon->value . '%' : '৳' . number_format($coupon->value)); ?>

                    </td>
                    <td class="px-5 py-3 text-gray-600">৳<?php echo e(number_format($coupon->min_order_amount)); ?></td>
                    <td class="px-5 py-3 text-gray-600">
                        <?php echo e($coupon->used_count); ?><?php echo e($coupon->usage_limit ? '/' . $coupon->usage_limit : ''); ?>

                    </td>
                    <td class="px-5 py-3 text-gray-600 text-xs">
                        <?php echo e($coupon->expires_at ? $coupon->expires_at->format('M d, Y') : 'Never'); ?>

                    </td>
                    <td class="px-5 py-3">
                        <?php if(!$coupon->is_active): ?>
                            <span class="px-2 py-1 bg-gray-100 text-gray-500 rounded-full text-xs">Inactive</span>
                        <?php elseif($coupon->is_expired): ?>
                            <span class="px-2 py-1 bg-red-100 text-red-600 rounded-full text-xs">Expired</span>
                        <?php else: ?>
                            <span class="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs">Active</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-5 py-3 flex gap-2">
                        <a href="<?php echo e(route('admin.coupons.edit', $coupon)); ?>" class="text-blue-500 hover:text-blue-700 text-xs font-medium">Edit</a>
                        <form action="<?php echo e(route('admin.coupons.destroy', $coupon)); ?>" method="POST" onsubmit="return confirm('Delete?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="text-red-400 hover:text-red-600 text-xs font-medium">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="px-5 py-12 text-center text-gray-400">No coupons yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    <div class="px-5 py-4 border-t border-gray-100"><?php echo e($coupons->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Laravel_Tutorial\claude\madiha-cloth-store\resources\views/admin/coupons/index.blade.php ENDPATH**/ ?>